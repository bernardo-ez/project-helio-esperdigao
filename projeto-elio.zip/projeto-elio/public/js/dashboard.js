document.addEventListener('DOMContentLoaded', () => {
    const logoutButton = document.getElementById('logoutButton');

    // Debug: verificar token
    const token = localStorage.getItem('token');
    console.log('Token encontrado:', token);
    
    // Removendo verificação que causa redirecionamento
    // if (!token) {
    //     console.log('Nenhum token encontrado, redirecionando...');
    //     window.location.href = 'index.html';
    //     return;
    // }

    console.log('Dashboard carregado com sucesso!');

    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            localStorage.removeItem('token');
            window.location.href = 'index.html';
        });
    }
});
