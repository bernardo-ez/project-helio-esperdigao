document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('errorMessage');
        
        try {
            const response = await fetch('/projeto-elio/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    username: username,
                    password: password
                })
            });
            
            const data = await response.json();
            console.log('Resposta da API:', data);
            
            if (response.ok && data.success) {
                console.log('Login bem-sucedido, salvando token...');
                localStorage.setItem('token', data.token);
                console.log('Token salvo:', localStorage.getItem('token'));
                window.location.href = 'dashboard.html';
            } else {
                errorDiv.textContent = data.error || 'Erro no login. Verifique suas credenciais.';
                errorDiv.style.display = 'block';
            }
        } catch (error) {
            console.error('Erro:', error);
            errorDiv.textContent = 'Erro de conexão com a API. Verifique se o servidor está rodando.';
            errorDiv.style.display = 'block';
        }
    });
});
